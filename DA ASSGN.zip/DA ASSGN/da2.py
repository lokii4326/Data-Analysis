# ✅ Step 1: Import Libraries
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from google.colab import files
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import confusion_matrix, classification_report

# ✅ Step 2: Upload File
print("📁 Upload Organization.csv")
uploaded = files.upload()
file_name = next(iter(uploaded))
data = pd.read_csv(file_name)
data.columns = data.columns.str.lower().str.replace(" ", "_")
print("✅ File loaded and columns standardized!")

# ✅ Step 3: Create Target - high vs low employee count
if 'number_of_employees' not in data.columns:
    raise ValueError("❌ 'number_of_employees' column missing.")
data['target'] = (data['number_of_employees'] > data['number_of_employees'].median()).astype(int)

# ✅ Step 4: Encode Categorical Columns
for col in ['industry', 'sector', 'organization']:
    if col in data.columns:
        data[col] = LabelEncoder().fit_transform(data[col])

# ✅ Step 5: Calculate Age of Organization
if 'founded' in data.columns:
    data['years_old'] = 2025 - data['founded']
else:
    raise ValueError("❌ 'founded' column missing for age calculation.")

# ✅ Step 6: Feature Selection & Standardization
features = ['industry', 'sector', 'organization', 'years_old']
X = StandardScaler().fit_transform(data[features])
y = data['target']

# ✅ Step 7: Train-Test Split
X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=42)

# ✅ Step 8: Train Model
model = RandomForestClassifier()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)

# ✅ Step 9: Evaluation
print("📊 Classification Report:\n")
print(classification_report(y_test, y_pred))

# ✅ Step 10: Enhanced Confusion Matrix
cm = confusion_matrix(y_test, y_pred)
labels = ['Low Employee (0)', 'High Employee (1)']

plt.figure(figsize=(6, 4))
sns.heatmap(cm, annot=True, fmt='d', cmap='YlGnBu',
            xticklabels=labels, yticklabels=labels, cbar=False)
plt.title("🧩 Confusion Matrix - High vs Low Employee Count")
plt.xlabel("Predicted Label")
plt.ylabel("True Label")
plt.tight_layout()
plt.show()
